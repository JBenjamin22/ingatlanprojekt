'use strict';
(() => {
  const app = document.querySelector('#app');
  const nav = document.querySelector('#nav');
  const toastElement = document.querySelector('#toast');
  document.querySelector('#year').textContent = String(new Date().getFullYear());
  const state = { user: null, csrfToken: null, renderId: 0 };
  const kindNames = { flat: 'Lakás', house: 'Családi ház', land: 'Telek', office: 'Iroda / üzlet' };
  const transactionNames = { sale: 'Eladó', rent: 'Kiadó' };
  let toastTimer;
  const esc = input => String(input ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  const money = value => new Intl.NumberFormat('hu-HU', { maximumFractionDigits: 0 }).format(value) + ' Ft';
  const dateHu = value => new Date(value).toLocaleDateString('hu-HU', { year: 'numeric', month: 'long', day: 'numeric' });
  const image = ad => ad.images?.[0]?.url || '/assets/placeholder.svg';
  const inputValue = (obj, key) => esc(obj?.[key] ?? '');
  const qp = (key, fallback = '') => new URLSearchParams(location.search).get(key) || fallback;

  function toast(message, isError = false) {
    clearTimeout(toastTimer);
    toastElement.textContent = message;
    toastElement.classList.toggle('error', isError);
    toastElement.hidden = false;
    toastTimer = setTimeout(() => { toastElement.hidden = true; }, 4300);
  }
  async function api(url, { method = 'GET', data, form } = {}) {
    const headers = {};
    if (method !== 'GET' && method !== 'HEAD') headers['X-CSRF-Token'] = state.csrfToken;
    if (data !== undefined) headers['Content-Type'] = 'application/json';
    let response;
    try {
      response = await fetch(url, { method, headers, credentials: 'same-origin', body: form || (data !== undefined ? JSON.stringify(data) : undefined) });
    } catch { throw Error('Nem sikerült elérni a szervert. Ellenőrizze a kapcsolatot.'); }
    let result;
    try { result = await response.json(); } catch { throw Error('A szerver válasza nem olvasható.'); }
    if (!response.ok) throw Error(result.error || 'Ismeretlen hiba történt.');
    return result;
  }
  function title(text) { document.title = text + ' | OtthonPont'; }
  function link(path, label, klass = '') { return `<a href="${esc(path)}" data-link class="${klass}">${label}</a>`; }
  function renderNav() {
    nav.innerHTML = `${link('/ingatlanok', 'Ingatlanok', location.pathname === '/ingatlanok' ? 'active' : '')}
      ${state.user ? `${link('/sajat-hirdeteseim', 'Hirdetéseim')}${link('/fiokom', 'Fiókom')}
      <button type="button" data-action="logout">Kijelentkezés</button>${link('/uj-hirdetes', '+ Új hirdetés', 'nav-cta')}`
      : `${link('/belepes', 'Bejelentkezés')}${link('/regisztracio', 'Regisztráció')}${link('/belepes', '+ Hirdetésfeladás', 'nav-cta')}`}`;
  }
  function navigate(url, replace = false) {
    if (replace) history.replaceState(null, '', url);
    else history.pushState(null, '', url);
    renderNav();
    render();
    window.scrollTo({ top: 0, behavior: 'instant' });
  }
  function loading() { app.innerHTML = '<div class="loading-page"><span class="spinner"></span> Betöltés…</div>'; }
  function errorUi(message) {
    app.innerHTML = `<section class="page container"><div class="empty-state"><div class="empty-icon">⚠️</div><h3>Nem sikerült megnyitni az oldalt</h3><p>${esc(message)}</p>${link('/ingatlanok', 'Vissza az ingatlanokhoz', 'btn btn-primary')}</div></section>`;
  }
  function emptyState(mine = false) {
    return `<div class="empty-state"><div class="empty-icon">⌂</div><h3>${mine ? 'Még nincs saját hirdetése' : 'Nincs találat a megadott szűrésre'}</h3>
      <p>${mine ? 'Hozza létre első ingatlanhirdetését! Fotókat is feltölthet hozzá.' : 'Próbáljon más keresési kifejezést vagy állítson a szűrőkön.'}</p>
      ${link(mine ? '/uj-hirdetes' : '/ingatlanok', mine ? '+ Első hirdetés feladása' : 'Szűrők törlése', 'btn btn-primary')}</div>`;
  }
  function adCard(ad, mine = false) {
    return `<article class="listing-card">
      <a href="/hirdetes/${ad.id}" data-link aria-label="${esc(ad.title)} hirdetésének megnyitása"><div class="card-image"><img src="${esc(image(ad))}" alt="${esc(ad.title)}" loading="lazy">
        <span class="pill">${transactionNames[ad.transactionType]}</span>${mine ? `<span class="pill neutral ${ad.isPublic ? '' : 'private'}">${ad.isPublic ? 'Nyilvános' : 'Privát'}</span>` : ''}</div></a>
      <div class="card-body"><div class="location">${esc(ad.city)}</div><h3 class="card-title">${link('/hirdetes/' + ad.id, esc(ad.title))}</h3>
      <div class="card-price">${money(ad.price)} ${ad.transactionType === 'rent' ? '<small>/ hó</small>' : ''}</div>
      <div class="card-meta"><span>${ad.area} m²</span><span>${ad.rooms} szoba</span><span>${esc(kindNames[ad.kind])}</span></div>
      ${mine ? `<div class="card-actions">${link('/hirdetes/' + ad.id + '/szerkesztes', 'Szerkesztés', 'btn btn-secondary btn-sm')}
      <button type="button" class="btn btn-danger btn-sm" data-action="delete-listing" data-id="${ad.id}">Törlés</button></div>` : ''}</div>
    </article>`;
  }
  function featureRow() {
    return `<section class="section-tint section-features"><div class="container"><div class="section-head"><div><div class="eyebrow">MIÉRT OTTHONPONT?</div><h2>Hirdessen egyszerűen, keressen okosan.</h2></div></div>
    <div class="features-grid">
      <div class="feature"><div class="feature-icon">⌕</div><h3>Átlátható keresés</h3><p>Keressen település, ingatlantípus és hirdetéstípus alapján.</p></div>
      <div class="feature"><div class="feature-icon">▧</div><h3>Több kép egy helyen</h3><p>Töltse fel saját ingatlanfotóit, és rendezze hirdetéseit.</p></div>
      <div class="feature"><div class="feature-icon">♙</div><h3>Teljes kontroll</h3><p>Csak Ön szerkesztheti vagy törölheti saját hirdetéseit.</p></div>
    </div></div></section>`;
  }
  async function home(renderId) {
    title('Ingatlanhirdetések');
    const result = await api('/api/listings');
    if (renderId !== state.renderId) return;
    app.innerHTML = `<section class="hero"><div class="container hero-grid"><div>
      <div class="eyebrow">AZ ÚJ OTTHONA ITT KEZDŐDIK</div><h1>Ingatlanhirdetések</h1>
      <p class="hero-lead">Eladó és kiadó ingatlanok keresése, saját hirdetések feladása.</p>
      <div class="hero-actions">${link('/ingatlanok', 'Ingatlanok megtekintése', 'btn btn-primary')}${link(state.user ? '/uj-hirdetes' : '/regisztracio', 'Saját hirdetés feladása', 'btn btn-outline')}</div>
      <div class="hero-tags"><span><b>✓</b> Átlátható kínálat</span><span><b>✓</b> Saját fotók</span><span><b>✓</b> Biztonságos fiók</span></div>
    </div><div class="hero-visual"><img src="/assets/hero.svg" alt="Illusztráció egy hangulatos családi házról"><div class="floating-note"><strong>${result.total} elérhető hirdetés</strong>Az új lehetőségek Önre várnak.</div></div></div></section>
    <section class="section"><div class="container"><div class="section-head"><div><div class="eyebrow">FRISS AJÁNLATOK</div><h2>Legújabb ingatlanok</h2><p>Fedezze fel a legfrissebb hirdetéseket.</p></div>${link('/ingatlanok', 'Összes ingatlan →', 'text-link')}</div>
    <div class="listing-grid">${result.items.length ? result.items.slice(0, 6).map(item => adCard(item)).join('') : emptyState(false)}</div></div></section>${featureRow()}`;
  }
  async function browse(renderId) {
    title('Eladó és kiadó ingatlanok');
    const result = await api('/api/listings' + location.search);
    if (renderId !== state.renderId) return;
    const selection = (current, value) => current === value ? 'selected' : '';
    app.innerHTML = `<section class="page"><div class="container"><div class="page-heading"><div class="eyebrow">INGATLAN KERESŐ</div><h1>Ingatlanok</h1><p>Szűrjön és találja meg az igényeinek megfelelő ajánlatot.</p></div>
      <form id="search-form" class="filters">
        <div class="field"><label for="q">Keresés</label><input id="q" name="q" value="${esc(qp('q'))}" placeholder="Pl. világos erkélyes lakás"></div>
        <div class="field"><label for="city">Település</label><input id="city" name="city" value="${esc(qp('city'))}" placeholder="Pl. Szeged"></div>
        <div class="field"><label for="transaction">Hirdetés</label><select id="transaction" name="transaction"><option value="">Mindegyik</option><option value="sale" ${selection(qp('transaction'), 'sale')}>Eladó</option><option value="rent" ${selection(qp('transaction'), 'rent')}>Kiadó</option></select></div>
        <div class="field"><label for="kind">Ingatlantípus</label><select id="kind" name="kind"><option value="">Mindegyik</option>${Object.entries(kindNames).map(([k,v]) => `<option value="${k}" ${selection(qp('kind'), k)}>${v}</option>`).join('')}</select></div>
        <div class="field"><label for="sort">Rendezés</label><select id="sort" name="sort"><option value="newest">Legújabb elöl</option><option value="priceAsc" ${selection(qp('sort'), 'priceAsc')}>Ár szerint növekvő</option><option value="priceDesc" ${selection(qp('sort'), 'priceDesc')}>Ár szerint csökkenő</option><option value="areaDesc" ${selection(qp('sort'), 'areaDesc')}>Méret szerint</option></select></div>
        <button class="btn btn-primary" type="submit">Keresés</button>
      </form><div class="results-bar"><div><strong>${result.total}</strong> találat</div><div>${result.pageCount ? result.page + '. oldal / ' + result.pageCount : 'Nincs találat'}</div></div>
      <div class="listing-grid">${result.items.length ? result.items.map(i => adCard(i)).join('') : emptyState()}</div>
      ${result.pageCount > 1 ? `<div class="pagination">${Array.from({ length: Math.min(result.pageCount, 8) }, (_, i) => i + 1).map(i => `<button type="button" class="page-number ${i === result.page ? 'active' : ''}" data-action="page" data-page="${i}">${i}</button>`).join('')}</div>` : ''}
      </div></section>`;
  }
  async function myListings(renderId) {
    if (!state.user) return navigate('/belepes');
    title('Saját hirdetéseim');
    const result = await api('/api/listings/mine');
    if (renderId !== state.renderId) return;
    app.innerHTML = `<section class="page container"><div class="page-heading split"><div><div class="eyebrow">SAJÁT FELÜLET</div><h1>Hirdetéseim</h1><p>${result.items.length} hirdetés – nyilvános és privát hirdetéseit is itt kezelheti.</p></div>${link('/uj-hirdetes', '+ Új hirdetés feladása', 'btn btn-primary')}</div>
      <div class="listing-grid">${result.items.length ? result.items.map(item => adCard(item, true)).join('') : emptyState(true)}</div></section>`;
  }
  async function listingDetails(id, renderId) {
    const { listing: ad } = await api(`/api/listings/${id}`);
    if (renderId !== state.renderId) return;
    title(ad.title);
    const own = state.user && state.user.id === ad.ownerId;
    const images = ad.images.length ? ad.images : [{ id: 0, url: '/assets/placeholder.svg' }];
    app.innerHTML = `<section class="page container"><div class="breadcrumbs">${link('/', 'Főoldal')} / ${link('/ingatlanok', 'Ingatlanok')} / ${esc(ad.title)}</div>
      <div class="detail-top"><div class="eyebrow">${transactionNames[ad.transactionType]} · ${esc(kindNames[ad.kind])} ${ad.isPublic ? '' : '· PRIVÁT'}</div>
      <h1>${esc(ad.title)}</h1><div class="detail-location">⌁ ${esc(ad.city)} ${ad.address ? '· ' + esc(ad.address) : ''} · Feladva: ${dateHu(ad.createdAt)}</div></div>
      <div class="detail-layout"><div><img id="large-image" class="detail-photo" src="${esc(images[0].url)}" alt="${esc(ad.title)}">
        ${images.length > 1 ? `<div class="detail-thumbs">${images.map((im,i) => `<button type="button" data-action="select-image" data-image="${esc(im.url)}" class="${i===0 ? 'selected' : ''}" aria-label="${i+1}. fénykép megtekintése"><img src="${esc(im.url)}" alt="${i+1}. ingatlankép"></button>`).join('')}</div>` : ''}
        <section class="detail-panel"><h2>Az ingatlanról</h2><p>${esc(ad.description)}</p></section></div>
      <aside><div class="side-panel"><div class="eyebrow">IRÁNYÁR</div><div class="detail-price">${money(ad.price)}</div><div class="muted">${ad.transactionType === 'rent' ? 'Havonta' : 'Vételár'}</div>
        <div class="detail-specs"><div><small>Alapterület</small><strong>${ad.area} m²</strong></div><div><small>Szobák</small><strong>${ad.rooms} szoba</strong></div><div><small>Típus</small><strong>${esc(kindNames[ad.kind])}</strong></div><div><small>Státusz</small><strong>${ad.isPublic ? 'Nyilvános' : 'Privát'}</strong></div></div>
        <div class="user-panel"><span class="avatar">${esc(ad.ownerName.charAt(0).toUpperCase())}</span><span><strong>${esc(ad.ownerName)}</strong><small>Hirdető</small></span></div>
        ${own ? `<div class="form-actions">${link('/hirdetes/' + ad.id + '/szerkesztes', 'Szerkesztés', 'btn btn-primary')}
          <button type="button" class="btn btn-danger" data-action="delete-listing" data-id="${ad.id}">Törlés</button></div>` : ''}
      </div></aside></div></section>`;
  }
  function formElement({ id, name, label, type = 'text', value = '', placeholder = '', required = true, min, max, step, helper = '' }) {
    const extras = `${min !== undefined ? ` min="${min}"` : ''}${max !== undefined ? ` max="${max}"` : ''}${step !== undefined ? ` step="${step}"` : ''}`;
    return `<div class="field"><label for="${id}">${label}</label><input id="${id}" name="${name}" type="${type}" value="${esc(value)}" placeholder="${esc(placeholder)}" ${required ? 'required' : ''}${extras}>${helper ? `<small>${helper}</small>` : ''}</div>`;
  }
  async function listingForm(id, renderId) {
    if (!state.user) return navigate('/belepes');
    let ad = null;
    if (id) {
      ad = (await api('/api/listings/' + id)).listing;
      if (!state.user || ad.ownerId !== state.user.id) return errorUi('Ezt a hirdetést nem szerkesztheti.');
    }
    if (renderId !== state.renderId) return;
    title(ad ? 'Hirdetés szerkesztése' : 'Új hirdetés feladása');
    const choose = (name, options, selected) => `<div class="field"><label for="${name}">${({kind:'Ingatlan típusa', transactionType:'Hirdetés típusa', isPublic:'Láthatóság'})[name]}</label><select id="${name}" name="${name}" required>${options.map(([k, val]) => `<option value="${esc(k)}" ${String(selected) === String(k) ? 'selected' : ''}>${esc(val)}</option>`).join('')}</select></div>`;
    app.innerHTML = `<section class="page container"><div class="page-heading"><div class="eyebrow">HIRDETÉSKEZELÉS</div><h1>${ad ? 'Hirdetés szerkesztése' : 'Új ingatlanhirdetés'}</h1><p>Adja meg az ingatlan adatait, és töltse fel a saját fényképeit.</p></div>
      <div class="form-layout"><form id="listing-form" class="form-panel"><h2 class="form-title">Az ingatlan adatai</h2><div id="form-feedback"></div>
      <div class="form-grid">
        <div class="span-two">${formElement({ id:'title',name:'title',label:'Hirdetés címe',value:ad?.title,placeholder:'Pl. Világos, felújított lakás az egyetem közelében' })}</div>
        ${choose('transactionType', [['sale','Eladó'],['rent','Kiadó']], ad?.transactionType || 'sale')}
        ${choose('kind', Object.entries(kindNames), ad?.kind || 'flat')}
        ${formElement({id:'price',name:'price',label:'Ár (Ft)',type:'number',min:1,max:100000000000,step:1,value:ad?.price,placeholder:'55000000'})}
        ${formElement({id:'area',name:'area',label:'Alapterület (m²)',type:'number',min:1,max:100000,step:1,value:ad?.area,placeholder:'72'})}
        ${formElement({id:'rooms',name:'rooms',label:'Szobák száma',type:'number',min:0,max:50,step:1,value:ad?.rooms ?? 2,placeholder:'3'})}
        ${formElement({id:'city',name:'city',label:'Település',value:ad?.city,placeholder:'Pl. Budapest'})}
        <div class="span-two">${formElement({id:'address',name:'address',label:'Utca, házszám (nem kötelező)',value:ad?.address,placeholder:'Pl. Béke utca 12.',required:false})}</div>
        <div class="field span-two"><label for="description">Részletes leírás</label><textarea id="description" name="description" minlength="20" maxlength="5000" required placeholder="Mutassa be az ingatlan előnyeit, elhelyezkedését, állapotát…">${esc(ad?.description || '')}</textarea><small>Legalább 20 karakter</small></div>
        ${choose('isPublic', [['true','Nyilvános – bárki megtekintheti'],['false','Privát – csak Ön láthatja']], ad ? String(ad.isPublic) : 'true')}
      </div><div class="form-divider"></div><h2 class="form-title">Fotók</h2><div class="field"><label for="images">Képek feltöltése</label><input id="images" name="images" type="file" accept="image/jpeg,image/png,image/webp" multiple><small>JPG, PNG vagy WEBP · max. 5 MB / kép · összesen legfeljebb 6 kép. Fotók nélkül is feladható hirdetés.</small></div>
      ${ad?.images?.length ? `<div class="helper existing-image-note">Már feltöltött képek (a törlés azonnal végrehajtódik):</div><div class="image-previews">${ad.images.map(im => `<div class="image-preview"><img src="${esc(im.url)}" alt="Korábban feltöltött kép"><button type="button" data-action="remove-image" data-listing-id="${ad.id}" data-image-id="${im.id}" aria-label="Kép törlése">✕ Törlés</button></div>`).join('')}</div>` : ''}
      <div id="new-previews" class="image-previews"></div>
      <div class="form-actions"><button type="submit" class="btn btn-primary" id="save-listing">${ad ? 'Változások mentése' : 'Hirdetés létrehozása'}</button>${link('/sajat-hirdeteseim', 'Mégse', 'btn btn-secondary')}</div>
      </form><aside class="side-panel"><h3>Hasznos tanácsok</h3><p>A részletes leírás és a jó minőségű fotók segítenek bemutatni ingatlanát.</p>
      <ul><li>Adjon meg pontos alapterületet.</li><li>Töltsön fel világos, éles képeket.</li><li>Ügyeljen a helyes árra.</li><li>Privát hirdetését mások nem látják.</li></ul></aside></div></section>`;
    document.querySelector('#images').addEventListener('change', e => {
      const container = document.querySelector('#new-previews');
      container.innerHTML = '';
      for (const file of e.target.files) {
        const url = URL.createObjectURL(file);
        const item = document.createElement('div');
        item.className = 'image-preview';
        const img = document.createElement('img');
        img.src = url; img.alt = file.name;
        img.onload = () => URL.revokeObjectURL(url);
        item.append(img);
        const caption = document.createElement('figcaption'); caption.textContent = file.name;
        item.append(caption);
        container.append(item);
      }
    });
  }
  function authPage(register) {
    if (state.user) return navigate('/sajat-hirdeteseim');
    title(register ? 'Regisztráció' : 'Bejelentkezés');
    app.innerHTML = `<section class="page container"><div class="auth-container"><form id="${register ? 'register-form' : 'login-form'}" class="auth-panel">
      <div class="eyebrow">${register ? 'CSATLAKOZZON HOZZÁNK' : 'ÜDVÖZÖLJÜK ÚJRA'}</div><h1>${register ? 'Regisztráció' : 'Bejelentkezés'}</h1>
      <p>${register ? 'Ingyenes regisztráció után saját ingatlanhirdetéseit is kezelheti.' : 'Lépjen be, hogy elérje és módosíthassa saját hirdetéseit.'}</p>
      <div id="form-feedback"></div><div class="stack-fields">
        ${register ? formElement({id:'name',name:'name',label:'Teljes név',placeholder:'Pl. Kovács Anna'}) : ''}
        ${formElement({id:'email',name:'email',label:'E-mail-cím',type:'email',placeholder:'nev@email.hu'})}
        ${formElement({id:'password',name:'password',label:'Jelszó',type:'password',placeholder:'Minimum 8 karakter',min:8,helper:register ? 'Minimum 8 karakter.' : ''})}
        <button class="btn btn-primary" type="submit">${register ? 'Regisztráció' : 'Bejelentkezés'} →</button></div>
      <p class="auth-bottom">${register ? 'Van már fiókja? ' + link('/belepes','Bejelentkezés') : 'Még nincs fiókja? ' + link('/regisztracio','Regisztráció')}</p>
      </form></div></section>`;
  }
  function profile() {
    if (!state.user) return navigate('/belepes');
    title('Fiókom');
    app.innerHTML = `<section class="page container"><div class="page-heading"><div class="eyebrow">SZEMÉLYES FIÓK</div><h1>Fiókbeállítások</h1><p>Itt módosíthatja személyes adatait, jelszavát és fiókját.</p></div>
      <div class="profile-layout"><form id="profile-form" class="profile-panel"><h2>Személyes adatok</h2><p>Ezek az adatok az Ön felhasználói fiókjához tartoznak.</p><div id="profile-feedback"></div>
        <div class="stack-fields">${formElement({id:'profile-name',name:'name',label:'Teljes név',value:state.user.name})}
        ${formElement({id:'profile-email',name:'email',label:'E-mail-cím',type:'email',value:state.user.email})}<button class="btn btn-primary" type="submit">Adatok mentése</button></div></form>
      <form id="password-form" class="profile-panel"><h2>Jelszó módosítása</h2><p>Válasszon legalább 8 karakteres, egyedi jelszót.</p><div id="password-feedback"></div>
        <div class="stack-fields">${formElement({id:'old-password',name:'currentPassword',label:'Jelenlegi jelszó',type:'password'})}
        ${formElement({id:'new-password',name:'newPassword',label:'Új jelszó',type:'password',min:8})}<button class="btn btn-secondary" type="submit">Jelszó módosítása</button></div></form>
      <form id="delete-profile-form" class="profile-panel danger"><h2>Fiók törlése</h2><p>A fiók és az összes hirdetés, feltöltött fénykép véglegesen törlődik. A művelet nem vonható vissza.</p>
        <div id="delete-profile-feedback"></div><div class="stack-fields">${formElement({id:'delete-password',name:'password',label:'Jelszó a megerősítéshez',type:'password'})}<button class="btn btn-danger" type="submit">Fiókom végleges törlése</button></div></form></div></section>`;
  }
  async function render() {
    const renderId = ++state.renderId;
    loading();
    try {
      const pathname = location.pathname;
      if (pathname === '/') return await home(renderId);
      if (pathname === '/ingatlanok') return await browse(renderId);
      if (pathname === '/sajat-hirdeteseim') return await myListings(renderId);
      if (pathname === '/uj-hirdetes') return await listingForm(null, renderId);
      if (pathname === '/belepes') return authPage(false);
      if (pathname === '/regisztracio') return authPage(true);
      if (pathname === '/fiokom') return profile();
      const detail = pathname.match(/^\/hirdetes\/(\d+)$/);
      if (detail) return await listingDetails(detail[1], renderId);
      const edit = pathname.match(/^\/hirdetes\/(\d+)\/szerkesztes$/);
      if (edit) return await listingForm(edit[1], renderId);
      title('Az oldal nem található');
      errorUi('A kért oldal nem létezik.');
    } catch (err) { if (renderId === state.renderId) errorUi(err.message); }
  }
  async function performSubmit(form, callback) {
    const button = form.querySelector('[type=submit]');
    const feedback = form.querySelector('[id$=feedback]');
    if (feedback) feedback.innerHTML = '';
    if (button) button.disabled = true;
    try { await callback(); }
    catch (err) {
      if (feedback) {
        const message = document.createElement('p');
        message.className = 'inline-error'; message.textContent = err.message;
        feedback.append(message);
      } else toast(err.message, true);
    } finally { if (button) button.disabled = false; }
  }
  document.addEventListener('click', async e => {
    const internal = e.target.closest('a[data-link]');
    if (internal && !e.ctrlKey && !e.metaKey && !e.shiftKey && !e.altKey && e.button === 0) {
      e.preventDefault(); navigate(internal.getAttribute('href')); return;
    }
    const control = e.target.closest('[data-action]');
    if (!control) return;
    const action = control.dataset.action;
    try {
      if (action === 'logout') {
        await api('/api/logout', { method: 'POST' });
        state.user = null;
        const result = await api('/api/session');
        state.csrfToken = result.csrfToken;
        toast('Sikeresen kijelentkezett.');
        navigate('/');
      }
      if (action === 'delete-listing') {
        if (!confirm('Biztosan véglegesen törölni szeretné ezt a hirdetést és minden képét?')) return;
        await api('/api/listings/' + control.dataset.id, { method: 'DELETE' });
        toast('A hirdetés törölve.');
        navigate('/sajat-hirdeteseim');
      }
      if (action === 'remove-image') {
        if (!confirm('Biztosan törli ezt a képet?')) return;
        await api(`/api/listings/${control.dataset.listingId}/images/${control.dataset.imageId}`, { method: 'DELETE' });
        toast('Kép sikeresen törölve.');
        render();
      }
      if (action === 'select-image') {
        const large = document.querySelector('#large-image');
        if (large) large.src = control.dataset.image;
        document.querySelectorAll('.detail-thumbs button').forEach(btn => btn.classList.toggle('selected', btn === control));
      }
      if (action === 'page') {
        const next = new URLSearchParams(location.search);
        next.set('page', control.dataset.page);
        navigate('/ingatlanok?' + next.toString());
      }
    } catch (err) { toast(err.message, true); }
  });
  document.addEventListener('submit', e => {
    const form = e.target;
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    if (form.id === 'search-form') {
      const search = new URLSearchParams();
      for (const [key, val] of Object.entries(data)) if (String(val).trim() && !(key === 'sort' && val === 'newest')) search.set(key, String(val).trim());
      return navigate('/ingatlanok' + (search.size ? '?' + search.toString() : ''));
    }
    if (form.id === 'register-form' || form.id === 'login-form') {
      return performSubmit(form, async () => {
        const result = await api(form.id === 'register-form' ? '/api/register' : '/api/login', { method: 'POST', data });
        state.user = result.user; state.csrfToken = result.csrfToken;
        toast(form.id === 'register-form' ? 'Regisztráció sikeres! Üdvözöljük!' : 'Sikeres bejelentkezés.');
        navigate('/sajat-hirdeteseim');
      });
    }
    if (form.id === 'listing-form') {
      return performSubmit(form, async () => {
        const edit = location.pathname.match(/^\/hirdetes\/(\d+)\/szerkesztes$/);
        const formData = new FormData(form);
        const files = form.querySelector('#images').files;
        if (files.length > 6) throw Error('Egyszerre legfeljebb 6 képet választhat ki.');
        for (const file of files) if (file.size > 5 * 1024 * 1024) throw Error('Egy fájl mérete legfeljebb 5 MB lehet.');
        const result = await api(edit ? '/api/listings/' + edit[1] : '/api/listings', { method: edit ? 'PUT' : 'POST', form: formData });
        toast(edit ? 'A hirdetés sikeresen módosítva.' : 'Az új hirdetés sikeresen létrehozva.');
        navigate('/hirdetes/' + result.listing.id);
      });
    }
    if (form.id === 'profile-form') {
      return performSubmit(form, async () => {
        const result = await api('/api/profile', { method: 'PATCH', data });
        state.user = result.user;
        renderNav(); toast('Személyes adatok frissítve.');
      });
    }
    if (form.id === 'password-form') {
      return performSubmit(form, async () => {
        await api('/api/profile/password', { method: 'PATCH', data });
        form.reset(); toast('Jelszó sikeresen megváltoztatva.');
      });
    }
    if (form.id === 'delete-profile-form') {
      if (!confirm('VÉGLEGES TÖRLÉS: minden hirdetése, fotója és fiókja törlődik. Folytatja?')) return;
      return performSubmit(form, async () => {
        await api('/api/profile', { method: 'DELETE', data });
        state.user = null;
        const response = await api('/api/session'); state.csrfToken = response.csrfToken;
        toast('A fiók véglegesen törölve.'); navigate('/');
      });
    }
  });
  window.addEventListener('popstate', () => { renderNav(); render(); });
  (async () => {
    try {
      const current = await api('/api/session');
      state.user = current.user; state.csrfToken = current.csrfToken;
      renderNav(); render();
    } catch (err) { errorUi(err.message); }
  })();
})();
