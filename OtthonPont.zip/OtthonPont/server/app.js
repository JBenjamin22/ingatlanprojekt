'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { openDatabase } = require('./db');
const { COOKIE_NAME, hashPassword, checkPassword, getAuth, issueSession, expiredCookie, csrfValid } = require('./security');
const { HttpError, fail, json, idFrom, readJson, readMultipart, cleanText, validateEmail, validatePassword, validateListing } = require('./http');

const PUBLIC_DIR = path.resolve(__dirname, '../public');
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.png': 'image/png', '.webp': 'image/webp' };

function createApp(options = {}) {
  const dbFile = options.dbFile || path.resolve(__dirname, '../data/otthonpont.sqlite');
  const uploadDir = options.uploadDir || path.resolve(__dirname, '../uploads');
  const cookieSecure = options.cookieSecure === true;
  fs.mkdirSync(uploadDir, { recursive: true });
  const db = openDatabase(dbFile);
  const authAttempts = new Map();

  function requireUser(auth) {
    if (!auth?.user) fail(401, 'Ehhez a művelethez be kell jelentkezni.');
    return auth.user;
  }
  function currentListing(id) {
    return db.prepare(`SELECT l.*, u.name AS owner_name FROM listings l JOIN users u ON u.id=l.owner_id WHERE l.id=?`).get(id);
  }
  function ownListing(id, auth) {
    const listing = currentListing(id);
    if (!listing || listing.owner_id !== requireUser(auth).id) fail(404, 'Nem található saját hirdetés ezen az azonosítón.');
    return listing;
  }
  function imageRecords(id) {
    return db.prepare('SELECT id FROM listing_images WHERE listing_id=? ORDER BY id').all(id)
      .map(r => ({ id: r.id, url: `/api/listings/${id}/images/${r.id}` }));
  }
  function listingView(row) {
    return {
      id: row.id, ownerId: row.owner_id, ownerName: row.owner_name,
      title: row.title, description: row.description, price: row.price,
      city: row.city, address: row.address, area: row.area, rooms: row.rooms,
      kind: row.kind, transactionType: row.transaction_type,
      isPublic: !!row.is_public, createdAt: row.created_at, updatedAt: row.updated_at,
      images: imageRecords(row.id)
    };
  }
  function saveFiles(files) {
    const stored = [];
    try {
      for (const file of files) {
        const name = crypto.randomUUID() + file.ext;
        fs.writeFileSync(path.join(uploadDir, name), file.bytes, { flag: 'wx', mode: 0o600 });
        stored.push({ name, mime: file.mime });
      }
      return stored;
    } catch (err) {
      eraseFiles(stored.map(f => f.name));
      throw err;
    }
  }
  function eraseFiles(names) {
    for (const name of names) {
      try { fs.unlinkSync(path.join(uploadDir, path.basename(name))); }
      catch (err) { if (err.code !== 'ENOENT') console.error('A képfájl törlése sikertelen:', err.message); }
    }
  }
  function limitLogins(req) {
    const now = Date.now();
    const ip = req.socket.remoteAddress || 'unknown';
    if (authAttempts.size > 5000) authAttempts.clear();
    const entry = authAttempts.get(ip);
    if (!entry || entry.resetAt < now) { authAttempts.set(ip, { count: 1, resetAt: now + 15 * 60000 }); return; }
    if (++entry.count > 30) fail(429, 'Túl sok próbálkozás. Próbálja újra 15 perc múlva.');
  }
  function sendStatic(res, file) {
    const body = fs.readFileSync(file);
    res.writeHead(200, {
      'Content-Type': (TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream') + (['.html', '.js', '.css', '.svg'].includes(path.extname(file)) ? '; charset=utf-8' : ''),
      'Cache-Control': file.endsWith('.html') ? 'no-cache' : 'public, max-age=86400'
    });
    res.end(body);
  }
  function serveImage(res, listingId, imageId, auth) {
    const row = db.prepare(`SELECT i.file_name,i.mime_type,l.owner_id,l.is_public
      FROM listing_images i JOIN listings l ON l.id=i.listing_id
      WHERE i.id=? AND i.listing_id=?`).get(imageId, listingId);
    if (!row || (!row.is_public && row.owner_id !== auth?.user?.id)) fail(404, 'A kép nem található.');
    const filename = path.join(uploadDir, path.basename(row.file_name));
    if (!fs.existsSync(filename)) fail(404, 'A képfájl hiányzik.');
    res.writeHead(200, { 'Content-Type': row.mime_type, 'Cache-Control': 'private, no-store' });
    fs.createReadStream(filename).pipe(res);
  }
  function withTransaction(fn) {
    db.exec('BEGIN IMMEDIATE');
    try { const result = fn(); db.exec('COMMIT'); return result; }
    catch (err) { db.exec('ROLLBACK'); throw err; }
  }

  async function route(req, res) {
    const u = new URL(req.url, 'http://localhost');
    const pathname = u.pathname;
    const method = req.method;
    const auth = getAuth(req, db);
    if (pathname === '/api/session' && method === 'GET') {
      db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now());
      const csrfToken = auth?.csrfToken || issueSession(db, res, null, cookieSecure);
      return json(res, 200, { user: auth?.user || null, csrfToken });
    }
    if (pathname.startsWith('/api/') && !['GET', 'HEAD'].includes(method) && !csrfValid(req, auth)) {
      fail(403, 'Érvénytelen biztonsági token. Frissítse az oldalt.');
    }
    if (pathname === '/api/register' && method === 'POST') {
      limitLogins(req);
      const data = await readJson(req);
      const name = cleanText(data.name, 2, 80, 'Név');
      const email = validateEmail(data.email);
      const password = validatePassword(data.password);
      if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) fail(409, 'Ez az e-mail-cím már foglalt.');
      let newId;
      try { newId = Number(db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name, email, hashPassword(password)).lastInsertRowid); }
      catch (err) { if (err.code === 'ERR_SQLITE_ERROR' || /UNIQUE constraint/.test(err.message)) fail(409, 'Ez az e-mail-cím már foglalt.'); throw err; }
      const csrfToken = issueSession(db, res, newId, cookieSecure, auth);
      return json(res, 201, { user: { id: newId, name, email }, csrfToken });
    }
    if (pathname === '/api/login' && method === 'POST') {
      limitLogins(req);
      const data = await readJson(req);
      const email = validateEmail(data.email);
      const password = typeof data.password === 'string' ? data.password : '';
      const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
      if (!user || !checkPassword(password, user.password_hash)) fail(401, 'Helytelen e-mail-cím vagy jelszó.');
      const csrfToken = issueSession(db, res, user.id, cookieSecure, auth);
      return json(res, 200, { user: { id: user.id, name: user.name, email: user.email }, csrfToken });
    }
    if (pathname === '/api/logout' && method === 'POST') {
      if (auth) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(auth.tokenHash);
      res.setHeader('Set-Cookie', expiredCookie(cookieSecure));
      return json(res, 200, { message: 'Sikeres kijelentkezés.' });
    }
    if (pathname === '/api/profile' && method === 'PATCH') {
      const user = requireUser(auth);
      const data = await readJson(req);
      const name = cleanText(data.name, 2, 80, 'Név');
      const email = validateEmail(data.email);
      if (db.prepare('SELECT id FROM users WHERE email=? AND id<>?').get(email, user.id)) fail(409, 'Ez az e-mail-cím már foglalt.');
      db.prepare('UPDATE users SET name=?,email=? WHERE id=?').run(name, email, user.id);
      return json(res, 200, { user: { id: user.id, name, email } });
    }
    if (pathname === '/api/profile/password' && method === 'PATCH') {
      const user = requireUser(auth);
      const data = await readJson(req);
      const previous = db.prepare('SELECT password_hash FROM users WHERE id=?').get(user.id);
      if (!previous || !checkPassword(String(data.currentPassword || ''), previous.password_hash)) fail(400, 'A jelenlegi jelszó helytelen.');
      const next = validatePassword(data.newPassword);
      db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(hashPassword(next), user.id);
      db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash<>?').run(user.id, auth.tokenHash);
      return json(res, 200, { message: 'Jelszó sikeresen módosítva.' });
    }
    if (pathname === '/api/profile' && method === 'DELETE') {
      const user = requireUser(auth);
      const data = await readJson(req);
      const record = db.prepare('SELECT password_hash FROM users WHERE id=?').get(user.id);
      if (!checkPassword(String(data.password || ''), record.password_hash)) fail(400, 'A jelszó helytelen.');
      const images = db.prepare(`SELECT i.file_name FROM listing_images i JOIN listings l ON l.id=i.listing_id WHERE l.owner_id=?`).all(user.id);
      db.prepare('DELETE FROM users WHERE id=?').run(user.id);
      eraseFiles(images.map(i => i.file_name));
      res.setHeader('Set-Cookie', expiredCookie(cookieSecure));
      return json(res, 200, { message: 'A fiók és összes hirdetése törölve.' });
    }
    if (pathname === '/api/listings' && method === 'GET') {
      const filters = ['l.is_public=1'];
      const params = [];
      const search = (u.searchParams.get('q') || '').trim().slice(0, 100);
      const city = (u.searchParams.get('city') || '').trim().slice(0, 80);
      const kind = u.searchParams.get('kind') || '';
      const transaction = u.searchParams.get('transaction') || '';
      if (search) { filters.push('(l.title LIKE ? OR l.description LIKE ? OR l.city LIKE ?)'); params.push(...Array(3).fill('%' + search + '%')); }
      if (city) { filters.push('l.city LIKE ?'); params.push('%' + city + '%'); }
      if (kind && ['flat', 'house', 'land', 'office'].includes(kind)) { filters.push('l.kind=?'); params.push(kind); }
      if (transaction && ['sale', 'rent'].includes(transaction)) { filters.push('l.transaction_type=?'); params.push(transaction); }
      const where = filters.join(' AND ');
      const total = db.prepare(`SELECT COUNT(*) AS count FROM listings l WHERE ${where}`).get(...params).count;
      const page = Math.min(10000, Math.max(1, Number.parseInt(u.searchParams.get('page') || '1', 10) || 1));
      const order = ({ newest: 'l.created_at DESC, l.id DESC', priceAsc: 'l.price ASC', priceDesc: 'l.price DESC', areaDesc: 'l.area DESC' })[u.searchParams.get('sort')] || 'l.created_at DESC, l.id DESC';
      const rows = db.prepare(`SELECT l.*,u.name AS owner_name FROM listings l JOIN users u ON l.owner_id=u.id WHERE ${where} ORDER BY ${order} LIMIT 12 OFFSET ?`).all(...params, (page - 1) * 12);
      return json(res, 200, { items: rows.map(listingView), total, page, pageCount: Math.ceil(total / 12) });
    }
    if (pathname === '/api/listings/mine' && method === 'GET') {
      const user = requireUser(auth);
      const rows = db.prepare('SELECT l.*,u.name AS owner_name FROM listings l JOIN users u ON l.owner_id=u.id WHERE l.owner_id=? ORDER BY l.created_at DESC,l.id DESC').all(user.id);
      return json(res, 200, { items: rows.map(listingView) });
    }
    if (pathname === '/api/listings' && method === 'POST') {
      const user = requireUser(auth);
      const { fields, files } = await readMultipart(req);
      const data = validateListing(fields);
      let saved = [];
      try {
        saved = saveFiles(files);
        const id = withTransaction(() => {
          const result = db.prepare(`INSERT INTO listings(owner_id,title,description,price,city,address,area,rooms,kind,transaction_type,is_public)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(user.id, data.title, data.description, data.price, data.city, data.address, data.area, data.rooms, data.kind, data.transactionType, data.isPublic);
          const listingId = Number(result.lastInsertRowid);
          for (const file of saved) db.prepare('INSERT INTO listing_images(listing_id,file_name,mime_type) VALUES(?,?,?)').run(listingId, file.name, file.mime);
          return listingId;
        });
        return json(res, 201, { listing: listingView(currentListing(id)) });
      } catch (err) { eraseFiles(saved.map(f => f.name)); throw err; }
    }
    const imageMatch = pathname.match(/^\/api\/listings\/(\d+)\/images\/(\d+)$/);
    if (imageMatch) {
      const listingId = idFrom(imageMatch[1]);
      const imageId = idFrom(imageMatch[2]);
      if (method === 'GET') return serveImage(res, listingId, imageId, auth);
      if (method === 'DELETE') {
        ownListing(listingId, auth);
        const record = db.prepare('SELECT file_name FROM listing_images WHERE id=? AND listing_id=?').get(imageId, listingId);
        if (!record) fail(404, 'A kép nem található.');
        db.prepare('DELETE FROM listing_images WHERE id=? AND listing_id=?').run(imageId, listingId);
        eraseFiles([record.file_name]);
        return json(res, 200, { message: 'Kép törölve.' });
      }
    }
    const listingMatch = pathname.match(/^\/api\/listings\/(\d+)$/);
    if (listingMatch) {
      const id = idFrom(listingMatch[1]);
      if (method === 'GET') {
        const record = currentListing(id);
        if (!record || (!record.is_public && record.owner_id !== auth?.user?.id)) fail(404, 'A hirdetés nem található.');
        return json(res, 200, { listing: listingView(record) });
      }
      if (method === 'PUT') {
        const record = ownListing(id, auth);
        const { fields, files } = await readMultipart(req);
        const data = validateListing(fields);
        const existingCount = db.prepare('SELECT COUNT(*) AS n FROM listing_images WHERE listing_id=?').get(record.id).n;
        if (existingCount + files.length > 6) fail(400, 'Egy hirdetéshez legfeljebb 6 kép tartozhat. Töröljön néhány régit.');
        let saved = [];
        try {
          saved = saveFiles(files);
          withTransaction(() => {
            db.prepare(`UPDATE listings SET title=?,description=?,price=?,city=?,address=?,area=?,rooms=?,kind=?,transaction_type=?,is_public=?,
                updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?`)
              .run(data.title, data.description, data.price, data.city, data.address, data.area, data.rooms, data.kind, data.transactionType, data.isPublic, id);
            for (const f of saved) db.prepare('INSERT INTO listing_images(listing_id,file_name,mime_type) VALUES(?,?,?)').run(id, f.name, f.mime);
          });
          return json(res, 200, { listing: listingView(currentListing(id)) });
        } catch (err) { eraseFiles(saved.map(f => f.name)); throw err; }
      }
      if (method === 'DELETE') {
        ownListing(id, auth);
        const images = db.prepare('SELECT file_name FROM listing_images WHERE listing_id=?').all(id);
        db.prepare('DELETE FROM listings WHERE id=?').run(id);
        eraseFiles(images.map(i => i.file_name));
        return json(res, 200, { message: 'Hirdetés törölve.' });
      }
    }
    if (pathname.startsWith('/api/')) fail(404, 'Ismeretlen API-végpont.');
    if (method === 'GET') {
      if (pathname === '/favicon.svg' || pathname.startsWith('/assets/')) {
        const relative = pathname.startsWith('/assets/') ? pathname.slice(1) : 'favicon.svg';
        const filename = path.resolve(PUBLIC_DIR, relative);
        if (!filename.startsWith(PUBLIC_DIR + path.sep) || !fs.existsSync(filename) || !fs.statSync(filename).isFile()) fail(404, 'A fájl nem található.');
        return sendStatic(res, filename);
      }
      return sendStatic(res, path.join(PUBLIC_DIR, 'index.html'));
    }
    fail(404, 'A kért útvonal nem létezik.');
  }

  async function handler(req, res) {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
    try { await route(req, res); }
    catch (err) {
      if (res.headersSent) { res.destroy(err); return; }
      if (!(err instanceof HttpError)) console.error('Szerverhiba:', err);
      json(res, err.status || 500, { error: err.status ? err.message : 'Váratlan szerverhiba történt.' });
    }
  }
  return { handler, db, close: () => db.close() };
}
module.exports = { createApp };
