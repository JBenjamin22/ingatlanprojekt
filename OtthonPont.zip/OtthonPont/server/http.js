'use strict';
const { URL } = require('node:url');

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
function fail(status, message) { throw new HttpError(status, message); }
function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
}
function idFrom(input) {
  if (!/^[1-9]\d{0,14}$/.test(input)) fail(404, 'Nem található.');
  const n = Number(input);
  if (!Number.isSafeInteger(n)) fail(404, 'Nem található.');
  return n;
}
async function bodyBuffer(req, maxSize) {
  const length = Number(req.headers['content-length'] || 0);
  if (length > maxSize) fail(413, 'Túl nagy a feltöltött adat.');
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > maxSize) fail(413, 'Túl nagy a feltöltött adat.');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}
async function readJson(req) {
  if (!(req.headers['content-type'] || '').toLowerCase().startsWith('application/json')) fail(415, 'JSON formátum szükséges.');
  const buf = await bodyBuffer(req, 64 * 1024);
  try {
    const value = JSON.parse(buf.toString('utf8'));
    if (value === null || typeof value !== 'object' || Array.isArray(value)) throw Error();
    return value;
  } catch { fail(400, 'Hibás JSON-adat.'); }
}
function imageType(bytes) {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return { mime: 'image/jpeg', ext: '.jpg' };
  if (bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return { mime: 'image/png', ext: '.png' };
  if (bytes.length >= 12 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP') return { mime: 'image/webp', ext: '.webp' };
  return null;
}
async function readMultipart(req) {
  const ct = req.headers['content-type'] || '';
  const found = ct.match(/^multipart\/form-data\s*;\s*boundary=(?:"([^"]+)"|([^;\s]+))/i);
  if (!found) fail(415, 'Az űrlapot multipart/form-data formátumban küldje el.');
  const boundary = found[1] || found[2];
  if (!boundary || boundary.length > 150) fail(400, 'Érvénytelen feltöltés.');
  const input = await bodyBuffer(req, 35 * 1024 * 1024);
  const delimiter = Buffer.from('--' + boundary);
  const separator = Buffer.from('\r\n\r\n');
  let cursor = 0;
  if (!input.subarray(0, delimiter.length).equals(delimiter)) fail(400, 'Érvénytelen multipart-adat.');
  const fields = {};
  const files = [];
  while (cursor < input.length) {
    if (!input.subarray(cursor, cursor + delimiter.length).equals(delimiter)) fail(400, 'Érvénytelen multipart-határ.');
    cursor += delimiter.length;
    if (input.toString('ascii', cursor, cursor + 2) === '--') break;
    if (input.toString('ascii', cursor, cursor + 2) !== '\r\n') fail(400, 'Érvénytelen multipart-fejléc.');
    cursor += 2;
    const headerEnd = input.indexOf(separator, cursor);
    if (headerEnd < 0 || headerEnd - cursor > 8192) fail(400, 'Érvénytelen multipart-fejléc.');
    const header = input.toString('utf8', cursor, headerEnd);
    const cd = header.match(/content-disposition:\s*form-data;\s*name="([a-zA-Z_][a-zA-Z_0-9]*)"(?:;\s*filename="([^"]*)")?/i);
    if (!cd) fail(400, 'Hiányzó űrlapmező.');
    cursor = headerEnd + separator.length;
    const next = input.indexOf(Buffer.from('\r\n--' + boundary), cursor);
    if (next < 0) fail(400, 'Sérült multipart-adat.');
    const value = input.subarray(cursor, next);
    cursor = next + 2;
    if (cd[2] !== undefined) {
      if (cd[1] !== 'images') fail(400, 'Ismeretlen fájlmező.');
      if (files.length >= 6) fail(400, 'Legfeljebb 6 képet tölthet fel egyszerre.');
      if (value.length > 5 * 1024 * 1024) fail(413, 'Egy kép legfeljebb 5 MB lehet.');
      const type = imageType(value);
      if (!type) fail(400, 'Csak JPG, PNG és WEBP képek tölthetők fel.');
      files.push({ bytes: value, ...type });
    } else {
      if (value.length > 12 * 1024) fail(400, 'Túl hosszú űrlapmező.');
      fields[cd[1]] = value.toString('utf8');
    }
  }
  return { fields, files };
}
function cleanText(value, min, max, label) {
  if (typeof value !== 'string') fail(400, `${label}: hiányzó érték.`);
  const s = value.trim().replace(/\s+/g, ' ');
  if (s.length < min || s.length > max) fail(400, `${label}: ${min}–${max} karakter szükséges.`);
  return s;
}
function validateEmail(value) {
  if (typeof value !== 'string') fail(400, 'Érvénytelen e-mail-cím.');
  const email = value.trim().toLowerCase();
  if (email.length > 254 || !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email)) fail(400, 'Érvénytelen e-mail-cím.');
  return email;
}
function validatePassword(value) {
  if (typeof value !== 'string' || value.length < 8 || value.length > 128) fail(400, 'A jelszó legalább 8, legfeljebb 128 karakter legyen.');
  return value;
}
function positiveInteger(value, min, max, label) {
  if (typeof value === 'boolean' || (typeof value === 'string' && !/^\d+$/.test(value))) fail(400, `${label}: érvénytelen szám.`);
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n < min || n > max) fail(400, `${label}: ${min} és ${max} közötti egész szám szükséges.`);
  return n;
}
function validateListing(fields) {
  const kind = fields.kind;
  const transactionType = fields.transactionType;
  if (!['flat', 'house', 'land', 'office'].includes(kind)) fail(400, 'Érvénytelen ingatlantípus.');
  if (!['sale', 'rent'].includes(transactionType)) fail(400, 'Érvénytelen hirdetéstípus.');
  if (!['true', 'false'].includes(String(fields.isPublic))) fail(400, 'Érvénytelen láthatósági beállítás.');
  return {
    title: cleanText(fields.title, 8, 120, 'Cím'),
    description: cleanText(fields.description, 20, 5000, 'Leírás'),
    price: positiveInteger(fields.price, 1, 100000000000, 'Ár'),
    city: cleanText(fields.city, 2, 80, 'Település'),
    address: typeof fields.address === 'string' ? cleanText(fields.address, 0, 160, 'Utca, házszám') : '',
    area: positiveInteger(fields.area, 1, 100000, 'Alapterület'),
    rooms: positiveInteger(fields.rooms, 0, 50, 'Szobák'),
    kind,
    transactionType,
    isPublic: String(fields.isPublic) === 'true' ? 1 : 0
  };
}
module.exports = { HttpError, fail, json, idFrom, readJson, readMultipart, cleanText, validateEmail, validatePassword, validateListing };
