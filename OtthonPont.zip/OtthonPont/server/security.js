'use strict';
const crypto = require('node:crypto');
const SESSION_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const COOKIE_NAME = 'otthon_session';

function randomToken() { return crypto.randomBytes(32).toString('hex'); }
function tokenHash(token) { return crypto.createHash('sha256').update(token).digest('hex'); }
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt:${salt}:${hash}`;
}
function checkPassword(password, stored) {
  if (typeof stored !== 'string' || !stored.startsWith('scrypt:')) return false;
  const parts = stored.split(':');
  if (parts.length !== 3 || !/^[a-f0-9]{32}$/i.test(parts[1]) || !/^[a-f0-9]{128}$/i.test(parts[2])) return false;
  const actual = crypto.scryptSync(password, parts[1], 64);
  return crypto.timingSafeEqual(actual, Buffer.from(parts[2], 'hex'));
}
function parseCookies(header = '') {
  const cookies = {};
  for (const part of header.split(';')) {
    const index = part.indexOf('=');
    if (index < 0) continue;
    const key = part.slice(0, index).trim();
    if (!key || Object.hasOwn(cookies, key)) continue;
    cookies[key] = part.slice(index + 1).trim();
  }
  return cookies;
}
function cookie(token, secure = false) {
  return `${COOKIE_NAME}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_AGE_MS / 1000}${secure ? '; Secure' : ''}`;
}
function expiredCookie(secure = false) {
  return `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure ? '; Secure' : ''}`;
}
function getAuth(req, db) {
  const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const token_hash = tokenHash(token);
  const session = db.prepare(`
    SELECT s.token_hash, s.user_id, s.csrf_token, u.name, u.email
    FROM sessions s LEFT JOIN users u ON u.id=s.user_id
    WHERE s.token_hash=? AND s.expires_at > ?
  `).get(token_hash, Date.now());
  if (!session) return null;
  return {
    tokenHash: token_hash,
    csrfToken: session.csrf_token,
    user: session.user_id === null ? null : { id: session.user_id, name: session.name, email: session.email }
  };
}
function issueSession(db, res, userId, secure, oldAuth = null) {
  if (oldAuth) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(oldAuth.tokenHash);
  const token = randomToken();
  const csrfToken = randomToken();
  db.prepare('INSERT INTO sessions(token_hash,user_id,csrf_token,expires_at) VALUES(?,?,?,?)')
    .run(tokenHash(token), userId, csrfToken, Date.now() + SESSION_AGE_MS);
  res.setHeader('Set-Cookie', cookie(token, secure));
  return csrfToken;
}
function csrfValid(req, auth) {
  const input = req.headers['x-csrf-token'];
  if (!auth || typeof input !== 'string' || !/^[a-f0-9]{64}$/.test(input)) return false;
  return crypto.timingSafeEqual(Buffer.from(input), Buffer.from(auth.csrfToken));
}
module.exports = { COOKIE_NAME, hashPassword, checkPassword, getAuth, issueSession, expiredCookie, csrfValid };
