'use strict';
const http = require('node:http');
const path = require('node:path');
const { createApp } = require('./app');
const port = Number(process.env.PORT) || 3000;
const app = createApp({
  dbFile: process.env.DB_FILE ? path.resolve(process.env.DB_FILE) : undefined,
  uploadDir: process.env.UPLOAD_DIR ? path.resolve(process.env.UPLOAD_DIR) : undefined,
  cookieSecure: process.env.COOKIE_SECURE === '1'
});
const server = http.createServer(app.handler);
server.listen(port, () => {
  console.log(`\n🏠 OtthonPont elindult: http://localhost:${port}`);
  console.log('Az adatbázis és a feltöltött képek helyileg tárolódnak.\n');
});
function shutdown() { server.close(() => { app.close(); process.exit(0); }); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
