'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const http = require('node:http');
const { createApp } = require('../server/app');

// Egyszerű 1x1 PNG – a teszt biztosítja a valós képfeltöltési útvonal használatát.
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/sJUAAAAASUVORK5CYII=', 'base64');

async function setup(t) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'otthonpont-test-'));
  const instance = createApp({ dbFile: path.join(dir, 'test.sqlite'), uploadDir: path.join(dir, 'uploads') });
  const server = http.createServer(instance.handler);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(async () => {
    await new Promise(resolve => server.close(resolve));
    instance.close();
    fs.rmSync(dir, { recursive: true, force: true });
  });
  const url = `http://127.0.0.1:${server.address().port}`;
  function client() {
    let cookie = '';
    let csrf = '';
    async function call(endpoint, { method = 'GET', data, form, headers = {} } = {}) {
      const reqHeaders = { ...headers };
      if (cookie) reqHeaders.Cookie = cookie;
      if (method !== 'GET' && method !== 'HEAD' && csrf && !Object.hasOwn(reqHeaders, 'X-CSRF-Token')) reqHeaders['X-CSRF-Token'] = csrf;
      if (data !== undefined) reqHeaders['Content-Type'] = 'application/json';
      const response = await fetch(url + endpoint, {
        method, headers: reqHeaders, body: form || (data !== undefined ? JSON.stringify(data) : undefined)
      });
      const set = response.headers.get('set-cookie');
      if (set) cookie = set.split(';')[0];
      const type = response.headers.get('content-type') || '';
      const body = type.includes('application/json') ? await response.json() : Buffer.from(await response.arrayBuffer());
      if (body.csrfToken) csrf = body.csrfToken;
      return { status: response.status, body, headers: response.headers };
    }
    return {
      call,
      init: () => call('/api/session'),
      register: (name, email) => call('/api/register', { method: 'POST', data: { name, email, password: 'NagyonBiztonsagos_2026!' } }),
      login: email => call('/api/login', { method: 'POST', data: { email, password: 'NagyonBiztonsagos_2026!' } }),
      csrf: () => csrf,
      cookie: () => cookie
    };
  }
  return { client, dir, url };
}
function listingForm(overrides = {}, withImage = true) {
  const defaults = {
    title: 'Napfényes lakás központi helyen', description: 'Szép állapotú, világos, két szobás lakás közel a központhoz.',
    price: '45000000', city: 'Szeged', address: 'Fő utca 12.', area: '71', rooms: '2',
    kind: 'flat', transactionType: 'sale', isPublic: 'true'
  };
  const form = new FormData();
  for (const [key, value] of Object.entries({ ...defaults, ...overrides })) form.append(key, value);
  if (withImage) form.append('images', new Blob([PNG], { type: 'image/png' }), 'lakaskep.png');
  return form;
}

test('Regisztráció, publikus listázás, keresés és több felhasználó adatainak elkülönítése', async t => {
  const { client } = await setup(t);
  const alice = client(), bob = client(), visitor = client();
  await alice.init(); await bob.init(); await visitor.init();
  assert.equal((await alice.register('Teszt Elek', 'elek@example.com')).status, 201);
  assert.equal((await bob.register('Másik Tulajdonos', 'masik@example.com')).status, 201);
  const published = await alice.call('/api/listings', { method: 'POST', form: listingForm() });
  assert.equal(published.status, 201);
  const id = published.body.listing.id;
  const pic = published.body.listing.images[0];
  assert.ok(pic.url.includes('/images/'));
  assert.equal((await visitor.call(pic.url)).status, 200);
  assert.equal((await visitor.call('/api/listings')).body.total, 1);
  assert.equal((await visitor.call('/api/listings?q=Napf%C3%A9nyes&city=Szeged')).body.total, 1);
  assert.equal((await visitor.call('/api/listings?city=Budapest')).body.total, 0);
  assert.equal((await bob.call('/api/listings/' + id, { method: 'DELETE' })).status, 404);
  assert.equal((await bob.call('/api/listings/' + id, { method: 'PUT', form: listingForm({ title: 'Jogosulatlan módosítás' }, false) })).status, 404);
  assert.equal((await bob.call('/api/listings/' + id + '/images/' + pic.id, { method: 'DELETE' })).status, 404);
  assert.equal((await bob.call('/api/listings/mine')).body.items.length, 0);
  assert.equal((await alice.call('/api/listings/mine')).body.items.length, 1);
  const hidden = await alice.call('/api/listings/' + id, { method: 'PUT', form: listingForm({ isPublic: 'false' }, false) });
  assert.equal(hidden.status, 200);
  assert.equal(hidden.body.listing.isPublic, false);
  assert.equal((await visitor.call('/api/listings')).body.total, 0);
  assert.equal((await visitor.call('/api/listings/' + id)).status, 404);
  assert.equal((await visitor.call(pic.url)).status, 404);
  assert.equal((await bob.call(pic.url)).status, 404);
  assert.equal((await alice.call(pic.url)).status, 200);
  assert.equal((await alice.call('/api/listings/' + id)).status, 200);
});

test('Kijelentkezés, újbóli bejelentkezés, profil- és jelszómódosítás', async t => {
  const { client } = await setup(t);
  const owner = client(); await owner.init();
  assert.equal((await owner.register('Árvíz Tűrő', 'arviz@example.com')).status, 201);
  assert.equal((await owner.call('/api/logout', { method: 'POST' })).status, 200);
  assert.equal((await owner.call('/api/listings/mine')).status, 401);
  await owner.init();
  assert.equal((await owner.login('arviz@example.com')).status, 200);
  const profile = await owner.call('/api/profile', { method: 'PATCH', data: { name: 'Új Felhasználónév', email: 'uj@example.com' } });
  assert.equal(profile.status, 200);
  assert.equal(profile.body.user.name, 'Új Felhasználónév');
  assert.equal((await owner.call('/api/profile/password', { method: 'PATCH', data: { currentPassword: 'hibas', newPassword: 'UjJelszo2026' } })).status, 400);
  assert.equal((await owner.call('/api/profile/password', { method: 'PATCH', data: { currentPassword: 'NagyonBiztonsagos_2026!', newPassword: 'UjJelszo2026' } })).status, 200);
  await owner.call('/api/logout', { method: 'POST' });
  await owner.init();
  assert.equal((await owner.login('uj@example.com')).status, 401);
  assert.equal((await owner.call('/api/login', { method: 'POST', data: { email: 'uj@example.com', password: 'UjJelszo2026' } })).status, 200);
});

test('Képtörlés, hirdetéstörlés, fióktörlés és fájlok eltakarítása', async t => {
  const { client, dir } = await setup(t);
  const owner = client(), guest = client(); await owner.init(); await guest.init();
  await owner.register('Törlési Próba', 'torles@example.com');
  const ad = (await owner.call('/api/listings', { method: 'POST', form: listingForm() })).body.listing;
  assert.equal(fs.readdirSync(path.join(dir, 'uploads')).length, 1);
  assert.equal((await owner.call(`/api/listings/${ad.id}/images/${ad.images[0].id}`, { method: 'DELETE' })).status, 200);
  assert.equal(fs.readdirSync(path.join(dir, 'uploads')).length, 0);
  const again = await owner.call('/api/listings/' + ad.id, { method: 'PUT', form: listingForm({}, true) });
  assert.equal(again.body.listing.images.length, 1);
  assert.equal((await owner.call('/api/listings/' + ad.id, { method: 'DELETE' })).status, 200);
  assert.equal(fs.readdirSync(path.join(dir, 'uploads')).length, 0);
  const next = await owner.call('/api/listings', { method: 'POST', form: listingForm() });
  assert.equal(next.status, 201);
  assert.equal((await owner.call('/api/profile', { method: 'DELETE', data: { password: 'rossz' } })).status, 400);
  assert.equal((await owner.call('/api/profile', { method: 'DELETE', data: { password: 'NagyonBiztonsagos_2026!' } })).status, 200);
  assert.equal(fs.readdirSync(path.join(dir, 'uploads')).length, 0);
  assert.equal((await guest.call('/api/listings')).body.total, 0);
  assert.equal((await owner.call('/api/listings/mine')).status, 401);
});

test('CSRF-védelem és hibás képfájlok elutasítása', async t => {
  const { client } = await setup(t);
  const owner = client(); await owner.init();
  await owner.register('Biztonsági Teszt', 'vedelem@example.com');
  assert.equal((await owner.call('/api/listings', { method: 'POST', form: listingForm(), headers: { 'X-CSRF-Token': 'hibas' } })).status, 403);
  const bad = listingForm({}, false);
  bad.append('images', new Blob([Buffer.from('Ez nem valodi kep')], { type: 'image/png' }), 'hamis.png');
  assert.equal((await owner.call('/api/listings', { method: 'POST', form: bad })).status, 400);
  const big = listingForm({}, false);
  big.append('images', new Blob([PNG, Buffer.alloc(5 * 1024 * 1024)], { type: 'image/png' }), 'tulnagy.png');
  assert.equal((await owner.call('/api/listings', { method: 'POST', form: big })).status, 413);
  assert.equal((await owner.call('/api/listings')).body.total, 0);
});
